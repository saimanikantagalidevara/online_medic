import React, { useState } from 'react';
import './doctordash.css';
import DoctorNavbar from './Doctornavbar';

const DoctorDash = () => {
    const [selectedPatient, setSelectedPatient] = useState(null);

    const patients = [
        {
            name: 'Alice Brown',
            age: 29,
            condition: 'Hypertension',
            history: {
                diagnoses: ['Hypertension', 'Seasonal Allergies'],
                treatments: ['Lifestyle changes', 'Antihypertensive medication'],
                allergies: ['Penicillin'],
                medications: ['Amlodipine', 'Cetirizine'],
                notes: 'Regular follow-up needed every 6 months.',
            },
        },
        {
            name: 'Bob White',
            age: 45,
            condition: 'Diabetes',
            history: {
                diagnoses: ['Type 2 Diabetes'],
                treatments: ['Diet control', 'Metformin'],
                allergies: ['Sulfa drugs'],
                medications: ['Metformin', 'Vitamin D'],
                notes: 'Monitor blood sugar levels weekly.',
            },
        },
        {
            name: 'Claire Adams',
            age: 34,
            condition: 'Asthma',
            history: {
                diagnoses: ['Asthma'],
                treatments: ['Inhaler therapy'],
                allergies: ['Dust mites'],
                medications: ['Albuterol inhaler'],
                notes: 'Avoid triggers and follow preventive care.',
            },
        },
    ];

    const handleViewHistory = (patient) => {
        setSelectedPatient(patient);
    };

    const closeHistory = () => {
        setSelectedPatient(null);
    };

    return (
        <div className="doctor-dash-container">
            <DoctorNavbar />
            <header className="doctor-dash-header">
                <h1>Doctor Dashboard</h1>
            </header>

            {/* Patient Overview Section */}
            <section className="doctor-dash-section">
                <h2>Patient Overview</h2>
                <div className="patients-list">
                    {patients.map((patient, index) => (
                        <div key={index} className="patient-card">
                            <p><strong>Name:</strong> {patient.name}</p>
                            <p><strong>Age:</strong> {patient.age}</p>
                            <p><strong>Condition:</strong> {patient.condition}</p>
                            <button
                                className="view-history-button"
                                onClick={() => handleViewHistory(patient)}
                            >
                                View Medical History
                            </button>
                        </div>
                    ))}
                </div>
            </section>

            {/* Medical History Modal */}
            {selectedPatient && (
                <div className="medical-history-modal">
                    <div className="modal-content">
                        <button className="close-button" onClick={closeHistory}>×</button>
                        <h2>{selectedPatient.name}'s Medical History</h2>
                        <p><strong>Age:</strong> {selectedPatient.age}</p>
                        <p><strong>Condition:</strong> {selectedPatient.condition}</p>
                        <hr />
                        <h3>Diagnoses</h3>
                        <ul>
                            {selectedPatient.history.diagnoses.map((item, index) => (
                                <li key={index}>{item}</li>
                            ))}
                        </ul>
                        <h3>Treatments</h3>
                        <ul>
                            {selectedPatient.history.treatments.map((item, index) => (
                                <li key={index}>{item}</li>
                            ))}
                        </ul>
                        <h3>Allergies</h3>
                        <ul>
                            {selectedPatient.history.allergies.map((item, index) => (
                                <li key={index}>{item}</li>
                            ))}
                        </ul>
                        <h3>Medications</h3>
                        <ul>
                            {selectedPatient.history.medications.map((item, index) => (
                                <li key={index}>{item}</li>
                            ))}
                        </ul>
                        <h3>Notes</h3>
                        <p>{selectedPatient.history.notes}</p>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DoctorDash;
