import React from 'react';
import { useParams } from 'react-router-dom';
import './patientPrescriptionPage.css';

const PatientPrescriptionPage = () => {
    const { patientId } = useParams();

    // Simulated prescription data for demonstration
    const prescriptions = [
        {
            patientId: '1',
            patientName: 'Alice Brown',
            prescriptions: [
                { medication: 'Amlodipine', dosage: '5mg once daily', instructions: 'Take after meals' },
                { medication: 'Paracetamol', dosage: '500mg as needed', instructions: 'For pain relief' },
            ],
        },
        {
            patientId: '2',
            patientName: 'Bob White',
            prescriptions: [
                { medication: 'Metformin', dosage: '500mg twice daily', instructions: 'Take with meals' },
            ],
        },
    ];

    // Find prescriptions for the patient
    const patientData = prescriptions.find((p) => p.patientId === patientId);

    return (
        <div className="patient-prescription-container">
            <h1>Prescription Details</h1>
            {patientData ? (
                <>
                    <h2>Patient: {patientData.patientName}</h2>
                    <div className="prescriptions-list">
                        {patientData.prescriptions.map((prescription, index) => (
                            <div key={index} className="prescription-card">
                                <p><strong>Medication:</strong> {prescription.medication}</p>
                                <p><strong>Dosage:</strong> {prescription.dosage}</p>
                                <p><strong>Instructions:</strong> {prescription.instructions}</p>
                            </div>
                        ))}
                    </div>
                </>
            ) : (
                <p>No prescriptions found for this patient.</p>
            )}
        </div>
    );
};

export default PatientPrescriptionPage;
