import React, { useState } from 'react';
import './prescriptionPage.css';

const PrescriptionPage = () => {
    const [prescriptions, setPrescriptions] = useState([]);
    const [newPrescription, setNewPrescription] = useState({
        patientName: '',
        medication: '',
        dosage: '',
        instructions: '',
    });

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewPrescription({ ...newPrescription, [name]: value });
    };

    const handleAddPrescription = () => {
        setPrescriptions([...prescriptions, newPrescription]);
        setNewPrescription({ patientName: '', medication: '', dosage: '', instructions: '' });
    };

    return (
        <div className="prescription-container">
            <h1>Prescription Management</h1>
            <div className="add-prescription-form">
                <input
                    type="text"
                    name="patientName"
                    placeholder="Patient Name"
                    value={newPrescription.patientName}
                    onChange={handleInputChange}
                />
                <input
                    type="text"
                    name="medication"
                    placeholder="Medication"
                    value={newPrescription.medication}
                    onChange={handleInputChange}
                />
                <input
                    type="text"
                    name="dosage"
                    placeholder="Dosage (e.g., 1 tablet twice daily)"
                    value={newPrescription.dosage}
                    onChange={handleInputChange}
                />
                <textarea
                    name="instructions"
                    placeholder="Instructions (e.g., after meals)"
                    value={newPrescription.instructions}
                    onChange={handleInputChange}
                />
                <button onClick={handleAddPrescription}>Add Prescription</button>
            </div>

            <div className="prescriptions-list">
                <h2>Prescriptions</h2>
                {prescriptions.length > 0 ? (
                    prescriptions.map((prescription, index) => (
                        <div key={index} className="prescription-card">
                            <p><strong>Patient:</strong> {prescription.patientName}</p>
                            <p><strong>Medication:</strong> {prescription.medication}</p>
                            <p><strong>Dosage:</strong> {prescription.dosage}</p>
                            <p><strong>Instructions:</strong> {prescription.instructions}</p>
                        </div>
                    ))
                ) : (
                    <p>No prescriptions added yet.</p>
                )}
            </div>
        </div>
    );
};

export default PrescriptionPage;
