package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthPlusApplication {

    public static void main(String[] args) {
        SpringApplication.run(HealthPlusApplication.class, args);
        System.out.println("Running....");
        
        
    }

}
